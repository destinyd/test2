require File.expand_path('./rails/init', File.dirname(__FILE__))
